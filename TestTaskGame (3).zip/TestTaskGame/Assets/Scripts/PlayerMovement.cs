using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] private int MoveSpeed = 5;
    [SerializeField] private FixedJoystick fixedJoystick;
    [SerializeField] private GameObject weapon;
    [SerializeField] TMP_Text bulletNumbers;
    public float distanceBetween;
    private GameObject enemy;
    private float distance;
    public Slider slider;

    private Rigidbody2D rb;
    private Vector2 moveDirection;
    private int bullets = 5;
    public int Health = 10;
    private float maxHealth;
    private Saved saved = new Saved();

    public void Start()
    {
        maxHealth = Health;
        rb = GetComponent<Rigidbody2D>();
        LoadFromJson();
        UpdateHealthSlider();
        UpdateBulletText();
    }

    //Updates

    public void UpdateBulletText()
    {
        bulletNumbers.text = bullets.ToString();
        SaveToJson();
    }

    public void Update()
    {
        ProcessInput();
        if (enemy != null)
            RotationWeapon();
        else
            findAllEnemyOnScene();
    }

    public void FixedUpdate()
    {
        Move();
    }

    public void UpdateHealthSlider()
    {
        float i = Health / maxHealth;
        slider.value = i;
    }

    //Movement

    private void ProcessInput()
    {
        float horizontal = fixedJoystick.Horizontal;
        float vertical = fixedJoystick.Vertical;
        Vector2 scalePlayer = transform.localScale;
        if (horizontal > 0 && enemy == null)
        {
            scalePlayer.x = 1;
        }
        if (horizontal < 0 && enemy == null)
        {
            scalePlayer.x = -1;
        }
        transform.localScale = scalePlayer;
        moveDirection = new Vector2(horizontal, vertical);
    }

    void Move()
    {
        rb.velocity = new Vector2(moveDirection.x * MoveSpeed, moveDirection.y * MoveSpeed);
    }

    //Weapon

    void RotationWeapon()
    {
        var dir = enemy.transform.position - transform.position;
        var angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;

        weapon.transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
        Vector2 scale = weapon.transform.localScale;
        Vector2 scalePlayer = transform.localScale;
        if (dir.x < 0)
        {
            scale.y = -0.6082894f;
            scale.x = -0.6082894f;
            scalePlayer.x = -1;
        }
        else if (dir.x > 0)
        {
            scale.y = 0.6082894f;
            scale.x = 0.6082894f;
            scalePlayer.x = 1;
        }
        transform.localScale = scalePlayer;
        weapon.transform.localScale = scale;
    }


    //Trigger
    public void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "PickUpAmmo")
        {
            bullets += 5;
            Destroy(other.gameObject);
            UpdateBulletText();
        }
    }

    //Enemy and shoot
    void findAllEnemyOnScene()
    {
        EnemyMovement[] foundSceneObjects = FindObjectsOfType<EnemyMovement>();
        foreach (EnemyMovement foundSceneObject in foundSceneObjects)
        {
            distance = Vector2.Distance(transform.position, foundSceneObject.gameObject.transform.position);
            if (distance < distanceBetween)
            {
                enemy = foundSceneObject.gameObject;
                break;
            }
        }
    }
    public void Damage()
    {
        Health -= 1;
        UpdateHealthSlider();
        if (Health <= 0)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    //Set / Get
    public bool GetEnemy()
    {
        if (enemy == null)
            return false;
        else
            return true;
    }
    public int GetBullets()
    {
        return bullets;
    }
    public void SetBullets()
    {
        bullets -= 1;
        UpdateBulletText();
    }

    public void LoadFromJson()
    {
        if (System.IO.File.Exists(Application.persistentDataPath + "/savedData.json"))
        {
            string filePath = Application.persistentDataPath + "/savedData.json";
            string savedDate = System.IO.File.ReadAllText(filePath);
            saved = JsonUtility.FromJson<Saved>(savedDate);
            bullets = saved.bulletsSaved;
        }

    }

    public void SaveToJson()
    {
        saved.bulletsSaved = bullets;
        string savedDate = JsonUtility.ToJson(saved);
        string filePath = Application.persistentDataPath + "/savedData.json";
        System.IO.File.WriteAllText(filePath, savedDate);

    }

}