using System.Collections.Generic;
using UnityEngine;


[System.Serializable]
public class Saved
{
    public int bulletsSaved;
}
