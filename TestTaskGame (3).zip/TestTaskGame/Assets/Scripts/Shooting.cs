using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooting : MonoBehaviour
{
    public GameObject bulletPrefab;
    public Transform firePoint;
    private PlayerMovement playerMovement;

    public float bulletForce = 20f;

    void Start()
    {
        playerMovement = GetComponent<PlayerMovement>();
    }

    public void Shoot()
    {
        if (playerMovement.GetEnemy() && playerMovement.GetBullets() > 0)
        {
            GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
            Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
            rb.AddForce(firePoint.right * bulletForce, ForceMode2D.Impulse);
            playerMovement.SetBullets();
        }
    }
}
