﻿
namespace V_ObjectSystem {

    public interface V_IActiveInactive {

        void SetActive();
        void SetInactive();

    }

}