using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    private GameObject player;
    public int MoveSpeed = 2;
    public float distanceBetween;
    public float distanceStop;
    public GameObject AmmoPrefab;
    public Slider slider;
    public int health = 5;
    private float maxHealth;

    private float distance;
    Coroutine lastRoutine = null;

    void Start()
    {
        maxHealth = health;
        UpdateSliderValue();
    }

    void findPlayerOnScene()
    {
        PlayerMovement[] foundSceneObjects = FindObjectsOfType<PlayerMovement>();
        foreach (PlayerMovement foundSceneObject in foundSceneObjects)
        {
            distance = Vector2.Distance(transform.position, foundSceneObject.gameObject.transform.position);
            if (distance < distanceBetween)
            {
                player = foundSceneObject.gameObject;
                break;
            }

        }
    }

    //Update
    void Update()
    {
        if (player != null)
        {
            distance = Vector2.Distance(transform.position, player.transform.position);
            Vector2 direction = player.transform.forward - transform.position;
            direction.Normalize();
            Vector2 scale = transform.localScale;
            Vector3 sliderScale = slider.transform.localScale;

            if (distance < distanceBetween && distance > distanceStop)
            {
                transform.position = Vector2.MoveTowards(this.transform.position, player.transform.position, MoveSpeed * Time.deltaTime);
            }
            if (player.transform.position.x < this.transform.position.x)
            {
                scale.x = -1f;
                sliderScale.x = -1f;
            }
            else if (player.transform.position.x >= this.transform.position.x)
            {
                scale.x = 1f;
                sliderScale.x = 1f;
            }
            transform.localScale = scale;

            slider.transform.localScale = sliderScale;
        }
        else
        {
            findPlayerOnScene();
        }
    }

    public void UpdateSliderValue()
    {
        float i = health / maxHealth;
        slider.value = i;
    }

    //Trigger
    public void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Bullet")
        {
            health -= 1;
            UpdateSliderValue();
            Destroy(other.gameObject);
            Debug.Log(health);
            if (health <= 0)
            {
                GameObject ammo = Instantiate(AmmoPrefab, transform.position, transform.rotation);
                Destroy(gameObject);
            }
        }
    }

    //Collision
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            lastRoutine = StartCoroutine(waiter());
        }
    }


    void OnCollisionExit2D(Collision2D collision)
    {
        StopCoroutine(lastRoutine);

    }

    IEnumerator waiter()
    {
        player.GetComponent<PlayerMovement>().Damage();
        yield return new WaitForSeconds(0.9f);
        lastRoutine = StartCoroutine(waiter());
    }
}
